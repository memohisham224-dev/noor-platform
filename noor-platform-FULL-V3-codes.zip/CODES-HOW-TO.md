# 🎟️ نظام أكواد الحصص
1- المدرس يدخل /codes -> يختار الدرس -> يولد كود
2- يبعت الكود للطالب واتساب: NOOR-XXXX-XXXX
3- الطالب يدخل /redeem -> يكتب الكود -> الحصة تتفتح
4- لو حد جرب نفس الكود تاني -> "اتستخدم قبل كده"
5- الكود بينتهي بعد 7 أيام (واحد) أو 30 يوم (جملة)
تعديل lessons/[id]: بدل isLocked اعمل check على LessonAccess
const hasAccess = await prisma.lessonAccess.findUnique({ where:{ userId_lessonId:{userId:currentUser.id, lessonId:lesson.id} } })
const isLocked = !isFree && !isOwner && !hasAccess
