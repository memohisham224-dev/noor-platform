import crypto from 'crypto'
export function generateCode(): string {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'
  let p1=''; let p2=''
  for(let i=0;i<4;i++){ p1+=chars[crypto.randomInt(chars.length)]; p2+=chars[crypto.randomInt(chars.length)] }
  return `NOOR-${p1}-${p2}`
}
export function generateBulkCodes(count:number): string[] {
  const s=new Set<string>()
  while(s.size<count) s.add(generateCode())
  return [...s]
}
