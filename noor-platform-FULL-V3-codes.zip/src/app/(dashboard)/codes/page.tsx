'use client'
import { useState } from 'react'
export default function CodesPage(){
  const [lessonId,setLessonId]=useState(''); const [count,setCount]=useState(10); const [codes,setCodes]=useState<string[]>([]); const [single,setSingle]=useState('')
  async function generate(){
    const res=await fetch('/api/codes/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({lessonId, count, method:'CASH'})})
    const d=await res.json(); if(d.codes) setCodes(d.codes); if(d.code) setSingle(d.code)
  }
  return <div dir='rtl' className='max-w-2xl mx-auto bg-white border rounded-2xl p-6 flex flex-col gap-3'>
    <h1 className='text-2xl font-bold'>🎟️ ولّد أكواد حصص</h1><p className='text-sm text-gray-500'>لو بتبيع في السنتر، ولّد 10 أكواد واطبعهم وبيعهم</p>
    <input value={lessonId} onChange={e=>setLessonId(e.target.value)} placeholder='ID الدرس' className='border rounded-xl p-3'/>
    <div className='flex gap-2'><input type='number' value={count} onChange={e=>setCount(Number(e.target.value))} className='border rounded-xl p-3 w-24'/><span className='self-center text-sm'>كود</span><button onClick={generate} className='bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold flex-1'>ولّد الأكواد</button></div>
    {single && <p className='bg-emerald-50 p-3 rounded-xl font-bold text-center'>الكود: {single}</p>}
    {codes.length>0 && <div className='border rounded-xl p-4'><div className='flex justify-between'><p className='font-bold'>الأكواد ({codes.length})</p><button onClick={()=>navigator.clipboard.writeText(codes.join('\n'))} className='text-sm bg-gray-100 px-3 py-1 rounded-lg'>📋 انسخ الكل</button></div><div className='grid grid-cols-2 gap-2 mt-3'>{codes.map(c=><div key={c} className='bg-gray-50 border rounded-lg p-2 text-center font-bold tracking-wider'>{c}</div>)}</div></div>}
  </div>
}
