'use client'
import { useState } from 'react'
import Link from 'next/link'
export default function RedeemPage(){
  const [code,setCode]=useState(''); const [msg,setMsg]=useState(''); const [isError,setIsError]=useState(false); const [lessonId,setLessonId]=useState('')
  async function submit(){
    setMsg(''); setIsError(false)
    const res=await fetch('/api/codes/redeem',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code, userId:'REPLACE_WITH_USER_ID'})})
    const d=await res.json()
    if(!res.ok){ setMsg(d.error); setIsError(true); return }
    setMsg(d.message); setLessonId(d.lessonId)
  }
  return <div dir='rtl' className='max-w-md mx-auto bg-white border rounded-2xl p-6 flex flex-col gap-4'>
    <h1 className='text-2xl font-bold text-center'>🔑 فعّل كود الحصة</h1>
    <p className='text-sm text-gray-500 text-center'>دفعت فودافون كاش؟ دخل الكود اللي اتبعتلك وافتح الحصة</p>
    <input value={code} onChange={e=>setCode(e.target.value.toUpperCase())} placeholder='NOOR-XXXX-XXXX' className='border-2 rounded-xl p-4 text-center text-xl font-bold tracking-widest uppercase'/>
    <button onClick={submit} className='bg-emerald-600 text-white py-3 rounded-xl font-bold'>فعّل الكود وافتح الحصة →</button>
    {msg && <div className={`p-4 rounded-xl text-sm font-bold text-center ${isError?'bg-red-50 text-red-600':'bg-emerald-50 text-emerald-700'}`}>{msg}{!isError && lessonId && <Link href={`/lessons/${lessonId}`} className='block mt-2 bg-emerald-600 text-white py-2 rounded-lg'>ادخل على الحصة دلوقتي ▶️</Link>}</div>}
    <div className='bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm'><p className='font-bold'>ازاي تجيب كود؟</p><ol className='mt-1 flex flex-col gap-1 text-gray-600'><li>1. حول الفلوس على فودافون كاش</li><li>2. ابعت صورة التحويل على واتساب</li><li>3. هنبعتلك الكود في أقل من ساعة</li><li>4. دخل الكود هنا وافتح الحصة</li></ol></div>
  </div>
}
