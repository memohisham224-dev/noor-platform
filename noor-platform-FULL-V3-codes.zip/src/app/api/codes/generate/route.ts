import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { generateCode, generateBulkCodes } from '@/lib/codes'
export async function POST(req:Request){
  const {lessonId, count=1, price, method} = await req.json()
  const lesson = await prisma.recordedLesson.findUnique({where:{id:lessonId}})
  if(!lesson) return NextResponse.json({error:'الدرس مش موجود'},{status:404})
  if(count===1){
    const c = await prisma.accessCode.create({ data:{ code: generateCode(), lessonId, teacherId: lesson.teacherId, price: price||lesson.price, method: method||'VODAFONE', expiresAt: new Date(Date.now()+7*24*60*60*1000) } })
    return NextResponse.json({ok:true, code:c.code})
  }
  const codes = generateBulkCodes(count)
  const created = await prisma.accessCode.createMany({ data: codes.map(c=>({ code:c, lessonId, teacherId: lesson.teacherId, price: price||lesson.price, method: method||'CASH', expiresAt: new Date(Date.now()+30*24*60*60*1000) })) })
  return NextResponse.json({ok:true, codes, count: created.count})
}
