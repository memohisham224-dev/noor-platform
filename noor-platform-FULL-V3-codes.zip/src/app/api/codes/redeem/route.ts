import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
export async function POST(req:Request){
  const {code, userId} = await req.json()
  const accessCode = await prisma.accessCode.findUnique({ where:{ code: code.trim().toUpperCase() }, include:{ lesson:true } })
  if(!accessCode) return NextResponse.json({error:'الكود ده مش موجود - اتأكد انك كاتبه صح'},{status:404})
  if(accessCode.isUsed) return NextResponse.json({error:'الكود ده اتستخدم قبل كده ❌ - كل كود بيتستخدم مرة واحدة بس'},{status:400})
  if(accessCode.expiresAt && accessCode.expiresAt < new Date()) return NextResponse.json({error:'الكود ده انتهى - اطلب كود جديد'},{status:400})
  const already = await prisma.lessonAccess.findUnique({ where:{ userId_lessonId:{ userId, lessonId: accessCode.lessonId } } })
  if(already) return NextResponse.json({error:'انت فاتح الدرس ده قبل كده'},{status:400})
  await prisma.$transaction([
    prisma.accessCode.update({ where:{id:accessCode.id}, data:{ isUsed:true, usedById:userId, usedAt:new Date() } }),
    prisma.lessonAccess.create({ data:{ userId, lessonId: accessCode.lessonId, codeId: accessCode.id } })
  ])
  return NextResponse.json({ ok:true, message:`مبروك! فتحت ${accessCode.lesson.title} 🎉`, lessonId: accessCode.lessonId })
}
