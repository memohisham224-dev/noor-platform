// prisma/seed.ts
// زي Laravel: Seeder + Factory
// تشغيل: npx prisma db push && npm run db:seed
// بيمسح الداتا القديمة وبيملي داتا جديدة كل مرة

import { PrismaClient, Role } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

// ============ Factory: داتا فيك ============
const FIRST_NAMES = ['أحمد','محمد','علي','عمر','يوسف','خالد','سعيد','طارق','كريم','مصطفى','سارة','نور','مريم','فاطمة','هاجر','آية','منى','ريم','ياسمين','ليلى','عمر','زياد','آدم','حمزة','بلال','هدى','شيماء','أمنية','دنيا','فرح']
const LAST_NAMES = ['نور','علي','حسن','إبراهيم','عبدالله','السيد','أحمد','محمود','خليل','عادل','شريف','كمال','فؤاد','نبيل','سالم','جمال']
const SUBJECTS = ['رياضيات','فيزياء','كيمياء','أحياء','عربي','انجليزي','فرنساوي','تاريخ','جغرافيا']
const GRADES = ['1 ثانوي','2 ثانوي','3 ثانوي','1 اعدادي','2 اعدادي','3 اعدادي']
const YT = [
  'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
  'https://www.youtube.com/watch?v=9bZkp7q19f0',
  'https://www.youtube.com/watch?v=kJQP7kiw5Fk',
]
const TITLES: Record<string,string[]> = {
  'رياضيات': ['التفاضل - الدرس الأول','التكامل - من الصفر','الجبر - المعادلات','الهندسة - الدائرة','الاحتمالات','النهايات','الاشتقاق','المصفوفات'],
  'فيزياء': ['الحركة - السرعة والعجلة','الكهرباء - الدائرة','المغناطيس','الضوء - الانكسار','الطاقة','الموجات','الديناميكا'],
  'كيمياء': ['الجدول الدوري','التفاعلات الكيميائية','الأحماض والقواعد','العضوية - الألكانات','الاتزان','الكيمياء الكهربائية'],
  'أحياء': ['الخلية','الوراثة - مندل','الجهاز العصبي','التكاثر','الهرمونات','المناعة'],
  'عربي': ['النحو - الفاعل','البلاغة - التشبيه','النصوص - الشعر','القراءة','التعبير'],
  'انجليزي': ['Grammar - Tenses','Vocabulary - Unit 1','Reading','Writing - Essay','Listening'],
  'فرنساوي': ['Les verbes','Vocabulaire','Grammaire','Compréhension'],
  'تاريخ': ['الثورة الفرنسية','الحرب العالمية','مصر الحديثة','الدولة العثمانية'],
  'جغرافيا': ['المناخ','التضاريس','السكان','الموارد'],
}
function rand<T>(arr:T[]):T{ return arr[Math.floor(Math.random()*arr.length)] }
function name(){ return `${rand(FIRST_NAMES)} ${rand(LAST_NAMES)}` }
function slug(s:string){ return s.replace(/\s+/g,'-') }

async function main(){
  console.log('🧹 بنمسح الداتا القديمة...')
  await prisma.payment.deleteMany()
  await prisma.progress.deleteMany()
  await prisma.recordedLesson.deleteMany()
  await prisma.user.deleteMany()

  const password = await bcrypt.hash('123456', 10)

  // ============ 1. Admin ============
  const admin = await prisma.user.create({ data:{ name:'صاحب المنصة', email:'admin@noor.eg', password, role:'ADMIN' } })
  console.log('👑 Admin:', admin.email, '/ 123456')

  // ============ 2. Teachers Factory - 12 مدرس ============
  console.log('👨‍🏫 بنعمل 12 مدرس...')
  const teachers = []
  for(let i=0;i<12;i++){
    const subject = SUBJECTS[i % SUBJECTS.length]
    const t = await prisma.user.create({ data:{
      name: `مستر ${name()}`,
      email: `teacher${i+1}@noor.eg`,
      password,
      role:'TEACHER',
      subject,
      grade: rand(GRADES),
      bio: `مدرس ${subject} خبرة ${5+i} سنين - شرح مبسط وامتحانات`,
      experience: 5+i,
    }})
    teachers.push(t)
  }
  // مدرس معروف تدخل بيه
  const heroTeacher = await prisma.user.create({ data:{ name:'مستر أحمد نور', email:'ahmed@noor.eg', password, role:'TEACHER', subject:'رياضيات', grade:'3 ثانوي', bio:'مدرس رياضيات - 15 سنة خبرة', experience:15 } })
  teachers.push(heroTeacher)

  // ============ 3. Students Factory - 30 طالب ============
  console.log('🎓 بنعمل 30 طالب...')
  const students = []
  for(let i=0;i<30;i++){
    const s = await prisma.user.create({ data:{
      name: name(),
      email: `student${i+1}@noor.eg`,
      password,
      role:'STUDENT',
      grade: rand(GRADES),
      school: rand(['مدرسة النور','مدرسة المستقبل','مدرسة الأمل','مدرسة السلام']),
    }})
    students.push(s)
  }
  const heroStudent = await prisma.user.create({ data:{ name:'سارة', email:'sara@noor.eg', password, role:'STUDENT', grade:'3 ثانوي', school:'مدرسة النور' } })
  students.push(heroStudent)

  // ============ 4. Parents - 5 أولياء أمور ============
  console.log('👪 بنعمل 5 أولياء أمور...')
  for(let i=0;i<5;i++){
    const child = students[i]
    await prisma.user.create({ data:{ name:`ولي أمر ${name()}`, email:`parent${i+1}@noor.eg`, password, role:'PARENT', childName: child.name, childGrade: child.grade||'3 ثانوي' } })
  }

  // ============ 5. Lessons Factory - 60 درس ============
  console.log('🎥 بنعمل 60 درس...')
  let lessonCount = 0
  for(const t of teachers){
    const titles = TITLES[t.subject||'رياضيات'] || TITLES['رياضيات']
    for(let j=0;j<5;j++){
      const isFree = j===0 // أول درس عند كل مدرس مجاني
      const status = j===4 ? 'DRAFT' : 'PUBLISHED' // آخر درس مسودة مستني موافقة الأدمن
      await prisma.recordedLesson.create({ data:{
        title: titles[j % titles.length] + (j>2 ? ` - جزء ${j-2}` : ''),
        description: `شرح ${titles[j % titles.length]} بالتفصيل - مع أمثلة وامتحانات - ملزمة PDF + واجب`,
        subject: t.subject||'رياضيات',
        grade: t.grade||'3 ثانوي',
        videoUrl: YT[lessonCount % YT.length],
        thumbnail: `https://i.ytimg.com/vi/${YT[lessonCount % YT.length].split('v=')[1]}/hqdefault.jpg`,
        duration: rand([900,1200,1500,1800,2400,2700]),
        price: isFree ? 0 : rand([0,50,80,100,120]),
        isFreeTrial: isFree,
        status: status as any,
        teacherId: t.id,
        pdfUrl: 'https://example.com/malzama.pdf',
        chapters: [
          { title:'المقدمة', start:0 },
          { title:'الشرح', start:300 },
          { title:'أمثلة', start:900 },
          { title:'الواجب', start:1500 },
        ],
      }})
      lessonCount++
    }
  }
  console.log(`✅ اتعمل ${lessonCount} درس`)

  // ============ 6. Progress Factory - كل طالب بيتفرج على دروس ============
  console.log('📊 بنعمل تقدم الطلاب...')
  const allLessons = await prisma.recordedLesson.findMany({ where:{status:'PUBLISHED'} })
  for(const s of students){
    // كل طالب بيتفرج على 3-8 دروس عشوائي
    const shuffled = [...allLessons].sort(()=>Math.random()-0.5).slice(0, 3+Math.floor(Math.random()*5))
    for(const l of shuffled){
      const watched = Math.floor(Math.random() * l.duration)
      await prisma.progress.create({ data:{
        userId: s.id,
        lessonId: l.id,
        watchedSec: watched,
        completed: watched >= l.duration*0.9,
      }})
    }
  }

  // ============ 7. Payments Factory ============
  console.log('💰 بنعمل مدفوعات...')
  const plans = ['monthly','term','year']
  const methods = ['VODAFONE','INSTAPAY','CARD','FAWRY']
  const amounts: Record<string,number> = { monthly:350, term:900, year:1500 }
  for(let i=0;i<15;i++){
    const s = rand(students)
    const plan = rand(plans)
    await prisma.payment.create({ data:{
      userId: s.id,
      plan,
      amount: amounts[plan],
      method: rand(methods),
      code: i%3===0 ? 'NOOR10' : null,
      status: i%5===0 ? 'PENDING' : 'COMPLETED',
    }})
  }

  console.log('')
  console.log('🎉 خلصنا! الداتا بيز اتملت')
  console.log('--------------------------------')
  console.log('👑 Admin: admin@noor.eg / 123456')
  console.log('👨‍🏫 مدرس: ahmed@noor.eg / 123456')
  console.log('🎓 طالب: sara@noor.eg / 123456')
  console.log('🎓 طالب تاني: student1@noor.eg / 123456')
  console.log('👪 ولي أمر: parent1@noor.eg / 123456')
  console.log(`📊 13 مدرس - 31 طالب - 5 ولي أمر - ${lessonCount} درس`)
}

main()
  .catch(e=>{ console.error(e); process.exit(1) })
  .finally(async()=>{ await prisma.$disconnect() })
