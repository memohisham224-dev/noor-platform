# منصة نور ✨ - دروس مسجلة | FULL
Next.js 16 + Prisma 7 + Neon + Zustand 5 + Tailwind 4
## تشغيل
npm install
cp .env.example .env  # حط DATABASE_URL
npx prisma db push
npm run db:seed
npm run dev -> http://localhost:3000
## صفحات
/ الهوم, /login, /register, /dashboard, /teachers, /teachers/[id], /lessons/[id], /lessons/new, /students, /parent, /checkout, /admin
## الدفع: شهري 350 - ترم 900 - سنة 1500 - كود NOOR10 خصم 10% - فودافون كاش / انستا باي / كارت / فوري
## الرفع: درس -> DRAFT -> ادمن يوافق -> PUBLISHED
## الفيديو: يكمل من نفس الثانية - سرعات 0.75/1/1.5/2 - 90% = completed - حفظ كل 5 ثواني

## 🎟️ أكواد الحصص (جديد)
- المدرس يولد كود من /codes
- الطالب يدخل الكود في /redeem
- الكود مرة واحدة بس - لو اتستخدم يقول اتستخدم قبل كده
- أكواد تجربة: NOOR-TEST-0001 (شغال) - NOOR-USED-0001 (مستخدم)

## ✨ كود نضيف V4 - Clean Code
- components/ui.tsx: StatCard + StatGrid + Page + Card + Field + PrimaryButton + Alert + HowTo + Empty
- components/TeacherCard.tsx: كان بيتكرر في 4 صفحات -> بقى ملف واحد
- components/LessonCard.tsx: كان بيتكرر في 4 صفحات -> بقى ملف واحد
- components/AuthForm.tsx: login + register بقوا ملف واحد (80% تشابه)
- dashboard/students/parent/admin بيستخدموا StatCard + Page
- checkout/codes/redeem بيستخدموا Alert + HowTo

## 📊 TanStack Table V5
- npm i @tanstack/react-table
- components/DataTable.tsx: جدول واحد لكل المشروع - بحث + ترتيب + صفحات
- students: StudentsTable - بحث على طالب/درس + ترتيب
- admin: AdminTable - بحث على درس/مدرس
- codes: CodesTable - بحث على كود + مين استخدمه
- dashboard / teachers / الهوم: لسه كروت - مش جدول - عشان عددهم صغير
