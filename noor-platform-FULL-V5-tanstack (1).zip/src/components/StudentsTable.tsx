'use client'
import { DataTable } from './DataTable'
import type { ColumnDef } from '@tanstack/react-table'
export type StudentRow = { id:string, student:string, lesson:string, watched:number, completed:boolean }
const columns: ColumnDef<StudentRow>[] = [
  { accessorKey:'student', header:'الطالب' },
  { accessorKey:'lesson', header:'الدرس' },
  { accessorKey:'watched', header:'اتفرج قد إيه', cell:({getValue})=>`${getValue<number>()} ث` },
  { accessorKey:'completed', header:'الحالة', cell:({getValue})=> getValue() ? <span className='bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full text-xs font-bold'>✅ خلص</span> : <span className='bg-amber-100 text-amber-700 px-2 py-1 rounded-full text-xs font-bold'>⏳ لسه</span> },
]
export function StudentsTable({ data }: { data: StudentRow[] }){ return <DataTable columns={columns} data={data} searchPlaceholder='دوّر على طالب أو درس...'/> }
