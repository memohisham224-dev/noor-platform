'use client'
import { DataTable } from './DataTable'
import type { ColumnDef } from '@tanstack/react-table'
export type CodeRow = { code:string, lesson:string, price:number, isUsed:boolean, usedBy:string }
const columns: ColumnDef<CodeRow>[] = [
  { accessorKey:'code', header:'الكود', cell:({getValue})=> <span className='font-bold tracking-wider'>{getValue<string>()}</span> },
  { accessorKey:'lesson', header:'الدرس' },
  { accessorKey:'price', header:'السعر', cell:({getValue})=> `${getValue<number>()} ج.م` },
  { accessorKey:'isUsed', header:'اتستخدم؟', cell:({getValue})=> getValue() ? <span className='bg-red-100 text-red-600 px-2 py-1 rounded-full text-xs font-bold'>❌ اتستخدم</span> : <span className='bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full text-xs font-bold'>✅ لسه جديد</span> },
  { accessorKey:'usedBy', header:'مين استخدمه' },
]
export function CodesTable({ data }: { data: CodeRow[] }){ return <DataTable columns={columns} data={data} searchPlaceholder='دوّر على كود أو درس...'/> }
