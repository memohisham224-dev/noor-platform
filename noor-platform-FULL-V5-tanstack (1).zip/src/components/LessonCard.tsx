// LessonCard - كان بيتكرر في الهوم + teachers/[id] + lessons/[id] + dashboard
import Link from 'next/link'
import { fmt } from '@/lib/utils'
type L = { id: string, title: string, subject?: string, grade?: string, price: number, duration?: number, isFreeTrial?: boolean, teacher?: { name: string } }
export function LessonCard({ lesson }: { lesson: L }) {
  return <Link href={`/lessons/${lesson.id}`} className='bg-white border rounded-2xl p-4 block hover:border-emerald-300'>
    <p className='text-xs text-emerald-600 font-bold'>{lesson.subject} {lesson.grade ? `- ${lesson.grade}` : ''}</p>
    <p className='font-bold mt-1 line-clamp-1'>{lesson.title}</p>
    <p className='text-sm text-gray-500 mt-1'>{lesson.teacher?.name || ''} {lesson.duration ? `- ${fmt(lesson.duration)}` : ''} - {lesson.price===0?'مجاني':lesson.price+' ج.م'} {lesson.isFreeTrial && '• مجاني للتجربة'}</p>
  </Link>
}
export function LessonRow({ lesson, right }: { lesson: L, right?: React.ReactNode }) {
  return <Link href={`/lessons/${lesson.id}`} className='border rounded-xl p-4 flex justify-between hover:border-emerald-300'><div><p className='font-bold'>{lesson.title}</p><p className='text-sm text-gray-500'>{lesson.subject} - {lesson.teacher?.name}</p></div>{right}</Link>
}
