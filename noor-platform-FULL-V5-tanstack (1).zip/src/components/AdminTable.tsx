'use client'
import Link from 'next/link'
import { DataTable } from './DataTable'
import type { ColumnDef } from '@tanstack/react-table'
export type DraftRow = { id:string, title:string, teacher:string, subject:string }
const columns: ColumnDef<DraftRow>[] = [
  { accessorKey:'title', header:'الدرس' },
  { accessorKey:'teacher', header:'المدرس' },
  { accessorKey:'subject', header:'المادة' },
  { accessorKey:'id', header:'', cell:({getValue})=> <Link href={`/lessons/${getValue<string>()}`} className='bg-emerald-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold'>راجع الدرس</Link> },
]
export function AdminTable({ data }: { data: DraftRow[] }){ return <DataTable columns={columns} data={data} searchPlaceholder='دوّر على درس أو مدرس...'/> }
