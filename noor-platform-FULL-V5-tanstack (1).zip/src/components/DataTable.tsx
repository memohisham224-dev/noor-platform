'use client'
import { useState } from 'react'
import { flexRender, getCoreRowModel, getFilteredRowModel, getSortedRowModel, getPaginationRowModel, useReactTable, type ColumnDef } from '@tanstack/react-table'
type Props<T> = { columns: ColumnDef<T>[], data: T[], searchPlaceholder?: string }
export function DataTable<T>({ columns, data, searchPlaceholder='دوّر...' }: Props<T>){
  const [sorting,setSorting]=useState<any[]>([])
  const [filter,setFilter]=useState('')
  const table = useReactTable({ data, columns, state:{ sorting, globalFilter: filter }, onSortingChange:setSorting, onGlobalFilterChange:setFilter, getCoreRowModel:getCoreRowModel(), getSortedRowModel:getSortedRowModel(), getFilteredRowModel:getFilteredRowModel(), getPaginationRowModel:getPaginationRowModel(), initialState:{ pagination:{ pageSize:10 } } })
  return <div dir='rtl' className='flex flex-col gap-3'>
    <input value={filter} onChange={e=>setFilter(e.target.value)} placeholder={searchPlaceholder} className='border rounded-xl p-3 w-full md:w-80'/>
    <div className='bg-white border rounded-2xl overflow-hidden'><table className='w-full text-sm'><thead className='bg-gray-50'>{table.getHeaderGroups().map(hg=><tr key={hg.id}>{hg.headers.map(h=><th key={h.id} onClick={h.column.getToggleSortingHandler()} className='p-3 text-right cursor-pointer select-none hover:bg-gray-100'>{flexRender(h.column.columnDef.header, h.getContext())}{h.column.getIsSorted()==='asc'?' ↑':h.column.getIsSorted()==='desc'?' ↓':''}</th>)}</tr>)}</thead><tbody>{table.getRowModel().rows.map(row=><tr key={row.id} className='border-t hover:bg-gray-50'>{row.getVisibleCells().map(cell=><td key={cell.id} className='p-3'>{flexRender(cell.column.columnDef.cell, cell.getContext())}</td>)}</tr>)}{table.getRowModel().rows.length===0 && <tr><td colSpan={columns.length} className='p-6 text-center text-gray-500'>مفيش نتائج</td></tr>}</tbody></table></div>
    <div className='flex justify-between items-center text-sm'><p>صفحة {table.getState().pagination.pageIndex+1} من {table.getPageCount()} - إجمالي {data.length}</p><div className='flex gap-2'><button disabled={!table.getCanPreviousPage()} onClick={()=>table.previousPage()} className='border px-3 py-1.5 rounded-lg disabled:opacity-40'>← اللي قبله</button><button disabled={!table.getCanNextPage()} onClick={()=>table.nextPage()} className='border px-3 py-1.5 rounded-lg disabled:opacity-40'>اللي بعده →</button></div></div>
  </div>
}
