// components/ui.tsx - كل الحاجات اللي بتتكرر في كل الصفحات
import Link from 'next/link'
import type { ReactNode } from 'react'

// 1. كارت إحصائية واحد - كان بيتكرر في dashboard + students + parent + admin
export function StatCard({ value, label }: { value: string|number, label: string }) {
  return <div className='bg-white border rounded-2xl p-4 text-center'><p className='font-bold text-2xl'>{value}</p><p className='text-sm text-gray-500'>{label}</p></div>
}
export function StatGrid({ children }: { children: ReactNode }) {
  return <div className='grid grid-cols-2 md:grid-cols-4 gap-4'>{children}</div>
}

// 2. حاوية الصفحة - كل الصفحات كانت بتعمل نفس الـ div
export function Page({ title, subtitle, children, wide }: { title: string, subtitle?: string, children: ReactNode, wide?: boolean }) {
  return <div dir='rtl' className={wide ? 'max-w-6xl mx-auto flex flex-col gap-6' : 'max-w-2xl mx-auto flex flex-col gap-5'}>
    <div><h1 className='text-2xl font-bold'>{title}</h1>{subtitle && <p className='text-gray-500 mt-1 text-sm'>{subtitle}</p>}</div>
    {children}
  </div>
}

// 3. كارت أبيض
export function Card({ children, className='' }: { children: ReactNode, className?: string }) {
  return <div className={`bg-white border rounded-2xl p-5 ${className}`}>{children}</div>
}

// 4. input واحد لكل الفورمات
export function Field({ label, ...props }: any) {
  return <label className='flex flex-col gap-1 text-sm font-bold'>{label}<input {...props} className='border rounded-xl p-3 font-normal' /></label>
}

// 5. زرار أخضر واحد
export function PrimaryButton({ children, ...props }: any) {
  return <button {...props} className='bg-emerald-600 text-white py-3 rounded-xl font-bold disabled:opacity-50'>{children}</button>
}

// 6. رسالة خطأ / نجاح - كانت بتتكرر في login + register + redeem + checkout
export function Alert({ type, children }: { type: 'error'|'success'|'info', children: ReactNode }) {
  const cls = type==='error' ? 'bg-red-50 text-red-600' : type==='success' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 border border-amber-200 text-gray-700'
  return <div className={`p-4 rounded-xl text-sm font-bold text-center ${cls}`}>{children}</div>
}

// 7. بوكس التعليمات الأصفر - كان بيتكرر في checkout + redeem + codes
export function HowTo({ title, steps }: { title: string, steps: string[] }) {
  return <div className='bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm'><p className='font-bold'>{title}</p><ol className='mt-1 flex flex-col gap-1 text-gray-600'>{steps.map((s,i)=><li key={i}>{i+1}. {s}</li>)}</ol></div>
}

// 8. حالة فاضية - "لسه مفيش..."
export function Empty({ text, href, cta }: { text: string, href?: string, cta?: string }) {
  return <div className='text-center py-6 text-gray-500'><p>{text}</p>{href && <Link href={href} className='inline-block mt-3 bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-bold'>{cta}</Link>}</div>
}
