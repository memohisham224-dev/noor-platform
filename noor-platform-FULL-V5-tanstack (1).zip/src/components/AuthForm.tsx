// AuthForm - كان login و register شبه بعض 80% - بقوا ملف واحد
'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Alert, Field, PrimaryButton } from './ui'
type Role = 'STUDENT'|'TEACHER'|'PARENT'
export function AuthForm({ mode }: { mode: 'login'|'register' }) {
  const router = useRouter()
  const [role, setRole] = useState<Role>('STUDENT')
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState('')
  const [grade,setGrade]=useState('3 ثانوي'); const [school,setSchool]=useState(''); const [subject,setSubject]=useState('رياضيات'); const [experience,setExperience]=useState(''); const [childName,setChildName]=useState(''); const [childGrade,setChildGrade]=useState('3 ثانوي')
  const [err,setErr]=useState(''); const [loading,setLoading]=useState(false)
  const isRegister = mode==='register'
  async function submit(e:React.FormEvent){
    e.preventDefault(); setErr(''); setLoading(true)
    const url = isRegister ? '/api/auth/register' : '/api/auth/login'
    const body:any = isRegister ? {name,email,password,role,grade,subject,school,experience:experience?Number(experience):undefined,childName,childGrade} : {email,password}
    const res = await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})
    const d = await res.json(); setLoading(false)
    if(!res.ok){ setErr(d.error||'حصل خطأ'); return }
    router.push('/dashboard')
  }
  const roles:[Role,string][]=[['STUDENT','طالب 🎓'],['TEACHER','مدرس 👨‍🏫'],['PARENT','ولي أمر 👪']]
  return <div dir='rtl' className='min-h-screen flex items-center justify-center px-4 py-8'>
    <form onSubmit={submit} className='bg-white border rounded-2xl p-6 w-full max-w-lg flex flex-col gap-3'>
      <h1 className='text-2xl font-bold text-center'>{isRegister?'اعمل حسابك مجانا ✨':'أهلا بيك تاني 👋'}</h1>
      <p className='text-center text-gray-500 text-sm'>{isRegister?'أول درس في كل كورس مجاني - جرب قبل ما تدفع':'ادخل عشان تكمل من مكان ما وقفت'}</p>
      {err && <Alert type='error'>{err}</Alert>}
      {isRegister && <div className='grid grid-cols-3 gap-2'>{roles.map(([r,label])=><button type='button' key={r} onClick={()=>setRole(r)} className={`py-3 rounded-xl font-bold text-sm ${role===r?'bg-emerald-600 text-white':'border'}`}>{label}</button>)}</div>}
      {isRegister && <Field label='الاسم بالكامل' value={name} onChange={(e:any)=>setName(e.target.value)} placeholder='الاسم بالكامل' required />}
      <Field label='الايميل' value={email} onChange={(e:any)=>setEmail(e.target.value)} placeholder='you@email.com' required />
      <Field label='الباسورد' type='password' value={password} onChange={(e:any)=>setPassword(e.target.value)} placeholder='••••••••' required />
      {isRegister && role==='STUDENT' && <><select value={grade} onChange={e=>setGrade(e.target.value)} className='border rounded-xl p-3'><option>1 ثانوي</option><option>2 ثانوي</option><option>3 ثانوي</option><option>1 اعدادي</option><option>2 اعدادي</option><option>3 اعدادي</option></select><input value={school} onChange={e=>setSchool(e.target.value)} placeholder='المدرسة (اختياري)' className='border rounded-xl p-3'/></>}
      {isRegister && role==='TEACHER' && <><select value={subject} onChange={e=>setSubject(e.target.value)} className='border rounded-xl p-3'><option>رياضيات</option><option>فيزياء</option><option>كيمياء</option><option>أحياء</option><option>عربي</option><option>انجليزي</option></select><select value={grade} onChange={e=>setGrade(e.target.value)} className='border rounded-xl p-3'><option>1 ثانوي</option><option>2 ثانوي</option><option>3 ثانوي</option></select><input value={experience} onChange={e=>setExperience(e.target.value)} placeholder='سنين الخبرة' type='number' className='border rounded-xl p-3'/></>}
      {isRegister && role==='PARENT' && <><input value={childName} onChange={e=>setChildName(e.target.value)} placeholder='اسم ابنك / بنتك' className='border rounded-xl p-3' required/><select value={childGrade} onChange={e=>setChildGrade(e.target.value)} className='border rounded-xl p-3'><option>1 ثانوي</option><option>2 ثانوي</option><option>3 ثانوي</option></select></>}
      <PrimaryButton disabled={loading}>{loading?'...': isRegister?'سجل وابدأ مجانا':'دخول'}</PrimaryButton>
      <Link href={isRegister?'/login':'/register'} className='text-center text-sm text-emerald-600 font-bold'>{isRegister?'عندك حساب؟ ادخل →':'معندكش حساب؟ سجل دلوقتي →'}</Link>
      <Link href='/' className='text-center text-sm text-gray-400'>← ارجع للهوم</Link>
    </form>
  </div>
}
