// TeacherCard - كان بيتكرر في teachers + teachers/[id] + lessons/[id] + الهوم
import Link from 'next/link'
type T = { id: string, name: string, subject?: string|null, grade?: string|null }
export function TeacherCard({ teacher, variant='card' }: { teacher: T, variant?: 'card'|'row' }) {
  if (variant==='row') return <div className='flex gap-3'><div className='w-14 h-14 bg-emerald-600 text-white rounded-2xl flex items-center justify-center text-xl font-bold shrink-0'>{teacher.name[0]}</div><div><p className='font-bold'>{teacher.name}</p><p className='text-sm text-gray-500'>مدرس {teacher.subject} - {teacher.grade}</p><p className='text-amber-500 text-sm'>★★★★★ 4.9 (128 تقييم)</p></div></div>
  return <Link href={`/teachers/${teacher.id}`} className='bg-white border rounded-2xl p-5 block hover:border-emerald-300'><p className='font-bold'>{teacher.name}</p><p className='text-sm text-gray-500'>{teacher.subject} - {teacher.grade}</p><p className='text-amber-500 text-sm mt-1'>★★★★★ 4.9</p></Link>
}
