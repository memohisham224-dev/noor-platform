import { prisma } from '@/lib/prisma'
import { CodesManager } from '@/components/CodesManager'
import type { CodeRow } from '@/components/CodesTable'
export default async function CodesPage(){
  const codes = await prisma.accessCode.findMany({ include:{ lesson:{select:{title:true}}, usedBy:{select:{name:true}} }, orderBy:{createdAt:'desc'}, take:100 })
  const data: CodeRow[] = codes.map(c=>({ code:c.code, lesson:c.lesson.title, price:c.price, isUsed:c.isUsed, usedBy:c.usedBy?.name || '-' }))
  return <div dir='rtl' className='max-w-4xl mx-auto'><CodesManager initialCodes={data}/></div>
}
