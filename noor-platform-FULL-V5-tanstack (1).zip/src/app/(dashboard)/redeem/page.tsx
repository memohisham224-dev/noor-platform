'use client'
import { useState } from 'react'
import Link from 'next/link'
import { Alert, HowTo, PrimaryButton } from '@/components/ui'
export default function RedeemPage(){
  const [code,setCode]=useState(''); const [msg,setMsg]=useState(''); const [isError,setIsError]=useState(false); const [lessonId,setLessonId]=useState('')
  async function submit(){ setMsg(''); setIsError(false); const res=await fetch('/api/codes/redeem',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code, userId:'REPLACE_WITH_USER_ID'})}); const d=await res.json(); if(!res.ok){ setMsg(d.error); setIsError(true); return } setMsg(d.message); setLessonId(d.lessonId) }
  return <div dir='rtl' className='max-w-md mx-auto bg-white border rounded-2xl p-6 flex flex-col gap-4'><h1 className='text-2xl font-bold text-center'>🔑 فعّل كود الحصة</h1><p className='text-sm text-gray-500 text-center'>دفعت فودافون كاش؟ دخل الكود اللي اتبعتلك</p><input value={code} onChange={e=>setCode(e.target.value.toUpperCase())} placeholder='NOOR-XXXX-XXXX' className='border-2 rounded-xl p-4 text-center text-xl font-bold tracking-widest uppercase'/><PrimaryButton onClick={submit}>فعّل الكود وافتح الحصة →</PrimaryButton>{msg && <Alert type={isError?'error':'success'}>{msg}{!isError && lessonId && <Link href={`/lessons/${lessonId}`} className='block mt-2 bg-emerald-600 text-white py-2 rounded-lg'>ادخل على الحصة دلوقتي ▶️</Link>}</Alert>}<HowTo title='ازاي تجيب كود؟' steps={['حول الفلوس على فودافون كاش','ابعت صورة التحويل على واتساب','هنبعتلك الكود في أقل من ساعة','دخل الكود هنا وافتح الحصة']} /></div>
}
