import { prisma } from '@/lib/prisma'
import { Page, StatGrid, StatCard, Card, Empty } from '@/components/ui'
import { AdminTable, type DraftRow } from '@/components/AdminTable'
export default async function Admin(){
  const drafts=await prisma.recordedLesson.findMany({where:{status:'DRAFT'},include:{teacher:{select:{name:true}}}})
  const published=await prisma.recordedLesson.count({where:{status:'PUBLISHED'}})
  const users=await prisma.user.count(); const payments=await prisma.payment.count()
  const data: DraftRow[] = drafts.map(d=>({id:d.id, title:d.title, teacher:d.teacher.name, subject:d.subject}))
  return <Page title='👑 لوحة الأدمن' wide><StatGrid><StatCard value={users} label='مستخدم'/><StatCard value={published} label='درس منشور'/><StatCard value={payments} label='دفعة'/></StatGrid><Card><h2 className='font-bold mb-3'>دروس مستنية الموافقة ({drafts.length})</h2>{drafts.length===0?<Empty text='مفيش دروس مستنية'/>:<AdminTable data={data}/>}</Card></Page>
}
