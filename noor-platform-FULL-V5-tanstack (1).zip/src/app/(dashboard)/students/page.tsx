import { prisma } from '@/lib/prisma'
import { Page, StatGrid, StatCard } from '@/components/ui'
import { StudentsTable, type StudentRow } from '@/components/StudentsTable'
export default async function Students(){
  const teacher=await prisma.user.findFirst({where:{role:'TEACHER'}})
  if(!teacher) return <Page title='طلابي'><p>مفيش مدرس</p></Page>
  const lessons=await prisma.recordedLesson.findMany({where:{teacherId:teacher.id}})
  const progress=await prisma.progress.findMany({where:{lessonId:{in:lessons.map(l=>l.id)}},include:{user:{select:{name:true}},lesson:{select:{title:true}}}})
  const done=progress.filter(p=>p.completed).length
  const data: StudentRow[] = progress.map(p=>({id:p.id, student:p.user.name, lesson:p.lesson.title, watched:p.watchedSec, completed:p.completed}))
  return <Page title={`👥 طلابي - ${teacher.name}`} wide><StatGrid><StatCard value={lessons.length} label='درس'/><StatCard value={progress.length} label='تقدم'/><StatCard value={done} label='درس خلص'/></StatGrid><StudentsTable data={data}/></Page>
}
