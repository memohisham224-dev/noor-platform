import { prisma } from '@/lib/prisma'
import { TeacherCard } from '@/components/TeacherCard'
import { Page, Empty } from '@/components/ui'
export default async function Teachers(){ const t=await prisma.user.findMany({where:{role:'TEACHER'}}); return <Page title='👨‍🏫 المدرسين' wide><div className='grid md:grid-cols-3 gap-4'>{t.map(x=><TeacherCard key={x.id} teacher={x}/>)}</div>{t.length===0 && <Empty text='لسه مفيش مدرسين'/>}</Page> }
