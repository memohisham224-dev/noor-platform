import Link from 'next/link'
import { notFound } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import { TeacherCard } from '@/components/TeacherCard'
import { LessonCard } from '@/components/LessonCard'
import { Card } from '@/components/ui'
export default async function TeacherPage({params}:{params:Promise<{id:string}>}){ const {id}=await params; const t=await prisma.user.findUnique({where:{id}}); if(!t||t.role!=='TEACHER') notFound(); const lessons=await prisma.recordedLesson.findMany({where:{teacherId:id,status:'PUBLISHED'}}); return <div dir='rtl' className='max-w-6xl mx-auto p-6 flex flex-col gap-6'><Card><TeacherCard teacher={t} variant='row'/></Card><div><h2 className='text-xl font-bold'>دروسه ({lessons.length})</h2><div className='grid md:grid-cols-3 gap-4 mt-3'>{lessons.map(l=><LessonCard key={l.id} lesson={l}/>)}</div></div><Link href='/checkout' className='bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold w-fit'>اشترك في كورس {t.subject}</Link></div> }
